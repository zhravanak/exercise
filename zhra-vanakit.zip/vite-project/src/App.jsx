import React, { useState } from "react";

function Page() {
  const [activePage, setActivePage] = useState(1);
  const pages = [
    {
      id: 1,
      name:"Page 1",
      title: "Countent 1",
      content:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed cumque exercitationem sapiente sunt reprehenderit ratione minima enim voluptatibus amet molestiae?",
    },
    {
      id: 2,
      name:"Page 2",
      title: "Countent 2",
      content:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed cumque exercitationem sapiente sunt reprehenderit ratione minima enim voluptatibus amet molestiae?",
    },
    {
      id: 3,
      name:"Page 3",
      title: "Countent 3",
      content:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed cumque exercitationem sapiente sunt reprehenderit ratione minima enim voluptatibus amet molestiae?",
    },
    {
      id: 4,
      name:"Page 4",
      title: "Countent  4",
      content:
        "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed cumque exercitationem sapiente sunt reprehenderit ratione minima enim voluptatibus amet molestiae?",
    },
  ];

  return (
    <>
      <div id="first">
        <h1 id="h1">Tabs Component </h1>
        {pages.map((page) => (
          <button
            id="button"
            key={page.id}
            onClick={() => setActivePage(page.id)}
          >
            {page.name}
          </button>
        ))}
      </div>
      <div id="sec">
        <h1 id="title">{pages[activePage - 1].title}</h1>
        <p id="p">{pages[activePage - 1].content}</p>
      </div>
    </>
  );
}

export default Page;
